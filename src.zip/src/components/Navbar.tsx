import { motion } from "framer-motion";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const links = [
  { label: "About", href: "#about" },
  { label: "Experience", href: "#experience" },
  { label: "Projects", href: "#projects" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <motion.header
      initial={{ y: -80 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6 }}
      className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-[#090909]/75 backdrop-blur-2xl"
    >
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-5 sm:px-8">

        {/* Logo */}

        <a
          href="#home"
          className="text-2xl font-black uppercase tracking-[0.18em] text-white sm:text-3xl lg:text-4xl lg:tracking-[0.28em]"
        >
          BAZAM
          <span className="text-yellow-400">.</span>
        </a>

        {/* Desktop Navigation */}

        <nav className="hidden items-center gap-8 lg:flex">
          {links.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-sm font-medium uppercase tracking-[0.18em] text-zinc-400 transition hover:text-white"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Desktop Button */}

        <a
          href="/Ayuba_Bazam_CV.pdf"
          download
          className="hidden rounded-full border border-yellow-400 px-6 py-3 font-semibold text-yellow-400 transition hover:bg-yellow-400 hover:text-black lg:block"
        >
          Download CV
        </a>

        {/* Mobile Menu Button */}

        <button
          onClick={() => setOpen(!open)}
          className="text-white lg:hidden"
        >
          {open ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}

      {open && (
        <div className="border-t border-white/10 bg-[#090909] lg:hidden">
          <nav className="flex flex-col px-5 py-6">
            {links.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={() => setOpen(false)}
                className="py-3 text-white"
              >
                {link.label}
              </a>
            ))}

            <a
              href="/Ayuba_Bazam_CV.pdf"
              download
              className="mt-4 rounded-full border border-yellow-400 px-5 py-3 text-center font-semibold text-yellow-400"
            >
              Download CV
            </a>
          </nav>
        </div>
      )}
    </motion.header>
  );
}